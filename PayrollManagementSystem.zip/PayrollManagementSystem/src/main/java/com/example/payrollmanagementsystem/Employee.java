package com.example.payrollmanagementsystem;

public class Employee extends abstractPerson {
    // You can add any additional fields specific to the Employee class here

    // Assuming you have overridden the necessary abstract methods from abstractPerson

    // toString method
    @Override
    public String toString() {
        return String.format("EMPLOYEE\nFull Name: %s\nEmployee ID: %s\nHourly Wage %.1f\nNumber of Hours Worked: %.1f\nTotal Pay: %.1f\n",
                getFullName(), getID(), getHourlyPay(), getWorkHours(), calc());
        // Add any additional information specific to the Employee class if needed
    }
}
