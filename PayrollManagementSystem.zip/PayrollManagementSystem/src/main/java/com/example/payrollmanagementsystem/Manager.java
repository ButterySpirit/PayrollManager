package com.example.payrollmanagementsystem;

public class Manager extends abstractPerson {
    // Defines private data fields
    private double overtimeHourlyPay;   // How much pay per hour: validate for positive #'s
    private double overtimeWorkHours;   // How many hours: validate for positive #'s and
    // max time (40 hours) overtime (58 hours)

    // SETTER METHODS
    public void setOvertimePay(double pay) { this.overtimeHourlyPay = pay; }
    public void setOvertimeHours(double hours) { this.overtimeWorkHours = hours; }

    // GETTER METHODS
    public double getOvertimePay() { return this.overtimeHourlyPay; }
    public double getOvertimeHours() { return this.overtimeWorkHours; }

    // Calculates overtime pay
    // total pay = hours * rate
    public double OverTimeCalc() { return this.overtimeHourlyPay * this.overtimeWorkHours; }
    public double totalCalc() { return calc() + OverTimeCalc(); }

    // toString method

    @Override
    public String toString() {
        return String.format("MANAGER\nFull Name: %s\nEmployee ID: %s\nHourly Wage %.1f\nNumber of Hours Worked: %.1f\nRegular Pay: %.1f\nOvertime Wage %.1f\nNumber of Overtime Hours Worked: %.1f\nOvertime Pay: %.1f\nTotal Pay: %.1f\n",
                getFullName(), getID(), getHourlyPay(), getWorkHours(), calc(), getOvertimePay(), getOvertimeHours(), OverTimeCalc(), totalCalc());
    }}

