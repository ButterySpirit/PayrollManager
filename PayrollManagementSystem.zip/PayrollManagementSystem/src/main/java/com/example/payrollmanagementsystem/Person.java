package com.example.payrollmanagementsystem;

public interface Person {
}
