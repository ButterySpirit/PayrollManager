package com.example.payrollmanagementsystem;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.TextArea;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.util.ArrayList;

public class HelloApplication extends Application {

    private Stage primaryStage;

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        this.primaryStage = primaryStage;
        primaryStage.setTitle("Payroll Management System");

        initializeMainMenu();

        primaryStage.show();
    }

    private void initializeMainMenu() {
        Label mainMenuLabel = new Label("Main Menu");
        Button addManagerButton = new Button("Add Manager");
        Button addEmployeeButton = new Button("Add Employee");
        Button viewReportsButton = new Button("View Payroll Reports");
        addManagerButton.setOnAction(e -> showAddManagerStage());
        addEmployeeButton.setOnAction(e -> showAddEmployeeStage());
        viewReportsButton.setOnAction(e -> showViewReportsStage());

        VBox mainMenuLayout = new VBox(10);
        mainMenuLayout.getChildren().addAll(mainMenuLabel, addManagerButton, addEmployeeButton, viewReportsButton);
        mainMenuLayout.setAlignment(javafx.geometry.Pos.CENTER);

        Scene mainMenuScene = new Scene(mainMenuLayout, 300, 200);
        primaryStage.setScene(mainMenuScene);
    }

    private void showMainMenu() {
        initializeMainMenu();
    }

    private void showAddManagerStage() {
        primaryStage.setScene(createAddManagerScene(primaryStage));
    }

    private Scene createAddManagerScene(Stage primaryStage) {
        Label nameLabel = new Label("Full Name:");
        TextField nameField = new TextField();

        Label idLabel = new Label("Employee ID (8 integers):");
        TextField idField = new TextField();

        Label hourlyPayLabel = new Label("Hourly Pay:");
        TextField hourlyPayField = new TextField();

        Label workHoursLabel = new Label("Work Hours:");
        TextField workHoursField = new TextField();

        Label overtimePayLabel = new Label("Overtime Pay:");
        TextField overtimePayField = new TextField();

        Label overtimeHoursLabel = new Label("Overtime Hours:");
        TextField overtimeHoursField = new TextField();

        Button submitButton = new Button("Submit");
        submitButton.setOnAction(e -> {
            if (validateManagerInput(nameField.getText(), idField.getText(), hourlyPayField.getText(),
                    workHoursField.getText(), overtimePayField.getText(), overtimeHoursField.getText())) {
                Manager manager = createManagerObject(nameField.getText(), idField.getText(),
                        Double.parseDouble(hourlyPayField.getText()), Double.parseDouble(workHoursField.getText()),
                        Double.parseDouble(overtimePayField.getText()), Double.parseDouble(overtimeHoursField.getText()));
                saveManagerToFile(manager, "output.csv");
            }
        });

        Button backToMainMenuButton = new Button("Back to Main Menu");
        backToMainMenuButton.setOnAction(e -> showMainMenu());

        VBox addManagerLayout = new VBox(10);
        addManagerLayout.setPadding(new Insets(10));
        addManagerLayout.getChildren().addAll(
                nameLabel, nameField,
                idLabel, idField,
                hourlyPayLabel, hourlyPayField,
                workHoursLabel, workHoursField,
                overtimePayLabel, overtimePayField,
                overtimeHoursLabel, overtimeHoursField,
                submitButton, backToMainMenuButton
        );

        return new Scene(addManagerLayout, 400, 300);
    }

    private boolean validateManagerInput(String name, String id, String hourlyPay, String workHours,
                                         String overtimePay, String overtimeHours) {
        if (name.isEmpty() || id.isEmpty() || hourlyPay.isEmpty() || workHours.isEmpty() ||
                overtimePay.isEmpty() || overtimeHours.isEmpty()) {
            showErrorAlert("Error: Empty Fields", "Please fill out all fields.");
            return false;
        }
        if (!isNumeric(id) || id.length() != 8) {
            showErrorAlert("Error: Invalid ID", "Please enter an ID with 8 integers.");
            return false;
        }
        if (!isNumeric(hourlyPay) || Double.parseDouble(hourlyPay) < 0) {
            showErrorAlert("Error: Invalid Hourly Pay", "Please enter a positive hourly pay.");
            return false;
        }
        if (!isNumeric(workHours) || Double.parseDouble(workHours) < 0 || Double.parseDouble(workHours) > 40) {
            showErrorAlert("Error: Invalid Work Hours", "Please enter a positive number of work hours, no more than 40.");
            return false;
        }
        if (!isNumeric(overtimePay) || Double.parseDouble(overtimePay) < 0) {
            showErrorAlert("Error: Invalid Overtime Pay", "Please enter a positive overtime pay.");
            return false;
        }
        if (!isNumeric(overtimeHours) || Double.parseDouble(overtimeHours) < 0 || Double.parseDouble(overtimeHours) > 18) {
            showErrorAlert("Error: Invalid Overtime Hours", "Please enter a positive number of overtime hours, no more than 18.");
            return false;
        }
        return true;
    }

    private Manager createManagerObject(String name, String id, double hourlyPay,
                                        double workHours, double overtimePay, double overtimeHours) {
        Manager manager = new Manager();
        manager.setFullName(name);
        manager.setID(id);
        manager.setHourlyPay(hourlyPay);
        manager.setWorkHours(workHours);
        manager.setOvertimePay(overtimePay);
        manager.setOvertimeHours(overtimeHours);
        return manager;
    }

    private void saveManagerToFile(Manager manager, String fileName) {
        ArrayList<Employee> employees = new ArrayList<>();
        Payroll.write(employees, manager, fileName);
        System.out.println("Manager data saved to file!");
    }

    private void showAddEmployeeStage() {
        primaryStage.setScene(createAddEmployeeScene(primaryStage));
    }

    private Scene createAddEmployeeScene(Stage primaryStage) {
        Label nameLabel = new Label("Full Name:");
        TextField nameField = new TextField();

        Label idLabel = new Label("Employee ID (8 integers):");
        TextField idField = new TextField();

        Label hourlyPayLabel = new Label("Hourly Pay:");
        TextField hourlyPayField = new TextField();

        Label workHoursLabel = new Label("Work Hours:");
        TextField workHoursField = new TextField();

        Button submitButton = new Button("Submit");
        submitButton.setOnAction(e -> {
            if (validateEmployeeInput(nameField.getText(), idField.getText(),
                    hourlyPayField.getText(), workHoursField.getText())) {
                Employee employee = createEmployeeObject(nameField.getText(), idField.getText(),
                        Double.parseDouble(hourlyPayField.getText()), Double.parseDouble(workHoursField.getText()));
                saveEmployeeToFile(employee, "output.csv");
            }
        });

        Button backToMainMenuButton = new Button("Back to Main Menu");
        backToMainMenuButton.setOnAction(e -> showMainMenu());

        VBox addEmployeeLayout = new VBox(10);
        addEmployeeLayout.setPadding(new Insets(10));
        addEmployeeLayout.getChildren().addAll(
                nameLabel, nameField,
                idLabel, idField,
                hourlyPayLabel, hourlyPayField,
                workHoursLabel, workHoursField,
                submitButton, backToMainMenuButton
        );

        return new Scene(addEmployeeLayout, 400, 250);
    }

    private boolean validateEmployeeInput(String name, String id, String hourlyPay, String workHours) {
        if (name.isEmpty() || id.isEmpty() || hourlyPay.isEmpty() || workHours.isEmpty()) {
            showErrorAlert("Error: Empty Fields", "Please fill out all fields.");
            return false;
        }
        if (!isNumeric(id) || id.length() != 8) {
            showErrorAlert("Error: Invalid ID", "Please enter an ID with 8 integers.");
            return false;
        }
        if (!isNumeric(hourlyPay) || Double.parseDouble(hourlyPay) < 0) {
            showErrorAlert("Error: Invalid Hourly Pay", "Please enter a positive hourly pay.");
            return false;
        }
        if (!isNumeric(workHours) || Double.parseDouble(workHours) < 0 || Double.parseDouble(workHours) > 40) {
            showErrorAlert("Error: Invalid Work Hours", "Please enter a positive number of work hours, no more than 40.");
            return false;
        }
        return true;
    }

    private Employee createEmployeeObject(String name, String id, double hourlyPay, double workHours) {
        Employee employee = new Employee();
        employee.setFullName(name);
        employee.setID(id);
        employee.setHourlyPay(hourlyPay);
        employee.setWorkHours(workHours);
        return employee;
    }

    private void saveEmployeeToFile(Employee employee, String fileName) {
        ArrayList<Person> people = PayrollReader.readDataFromCSV(fileName);
        people.add(employee);
        Payroll.write(people, null, fileName);
        System.out.println("Employee data saved to file!");
    }



    private void showViewReportsStage() {
        primaryStage.setScene(createViewReportsScene(primaryStage));
    }

    private Scene createViewReportsScene(Stage primaryStage) {
        Button backToMainMenuButton = new Button("Back to Main Menu");
        backToMainMenuButton.setOnAction(e -> showMainMenu());

        // Retrieve manager and employee data from the file and print it to a text area
        ArrayList<Person> people = PayrollReader.readDataFromCSV("output.csv");

        // Create a text area to display the reports
        TextArea textArea = new TextArea();
        textArea.setEditable(false);
        textArea.setPrefHeight(300);
        textArea.setPrefWidth(400);
        textArea.setText("Payroll Report\n\n");

        for (Person person : people) {
            textArea.appendText(person.toString() + "\n");
        }

        // Create a layout to hold the text area and back button
        VBox viewReportsLayout = new VBox(10);
        viewReportsLayout.setPadding(new Insets(10));
        viewReportsLayout.getChildren().add(textArea);

        // Add the back button
        viewReportsLayout.getChildren().add(backToMainMenuButton);

        return new Scene(viewReportsLayout, 500, 400);
    }

    private void showErrorAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(message);
        alert.showAndWait();
    }

    private static boolean isNumeric(String str) {
        return str.matches("\\d+");
    }
}
