package com.example.payrollmanagementsystem;
import java.io.*;
import java.lang.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;

public class Payroll {
    // Static scanner object for multiple uses
    private static Scanner input = new Scanner(System.in);
    private static int validate(int num){
        while (num < 1 || num > 2){
            System.out.print("INVALID INPUT. Please enter an option listed above (1 or 2): " );
            num = input.nextInt();
        }

        // Returns valid menu options
        return num;
    }

    private static void INPUT(Manager manager1){
        // Creates a dummy variable to validate input
        String tempS;

        // FULL NAME
        System.out.println("\nPlease enter data for the Manager in charge of "
                + "these three employees.");
        System.out.print("Full name: ");
        tempS = input.nextLine();
        manager1.setFullName(tempS);

        // ID INPUT VALIDATION
        System.out.print("Please enter an ID (8 integers): ");
        tempS = input.nextLine();
        while(!isNumeric(tempS) || tempS.length() != 8){
            System.out.print("Invalid ID. Please enter an ID with 8 integers: ");
            tempS = input.nextLine();
        }
        manager1.setID(tempS);  // Accepted if valid

        // HOURLY RATE
        System.out.print("Please enter an hourly rate: ");
        tempS = input.nextLine();
        while(!isNumeric(tempS)){
            System.out.print("Invalid rate. Please make sure it is positive. ");
            tempS = input.nextLine();
        }
        manager1.setHourlyPay(Double.parseDouble(tempS));   // Accepted if valid

        // NUMBER OF HOURS
        System.out.print("Please enter the number of REGULAR hours worked: ");
        tempS = input.nextLine();
        while(!isNumeric(tempS) || Double.parseDouble(tempS) > 40){
            System.out.print("Invalid number. Please make sure it is positive "
                    + "and no more than 40 hours. ");
            tempS = input.nextLine();
        }
        manager1.setWorkHours(Double.parseDouble(tempS));   // Accepted if valid

        // OVERTIME HOURLY RATE
        System.out.print("Please enter an OVERTIME hourly rate: ");
        tempS = input.nextLine();
        while(!isNumeric(tempS)){
            System.out.print("Invalid rate. Please make sure it is positive. ");
            tempS = input.nextLine();
        }
        manager1.setOvertimePay(Double.parseDouble(tempS));   // Accepted if valid

        // NUMBER OF OVERTIME HOURS (0-18)
        System.out.print("Please enter the number of OVERTIME hours worked: ");
        tempS = input.nextLine();
        while(!isNumeric(tempS) || Double.parseDouble(tempS) > 18){
            System.out.print("Invalid number. Please make sure it is positive "
                    + "and no more than 18 hours. ");
            tempS = input.nextLine();
        }
        manager1.setOvertimeHours(Double.parseDouble(tempS));   // Accepted if valid

    }

    /**********************************************
     * These functions accept input from the user.
     * Employees Function
     **********************************************/
    private static void INPUT(ArrayList<Employee> e){
        // Creates a dummy variable to validate input
        String tempS;

        // DATA ENTERING PROCEDURE
        for (int i = 0; i < e.size(); i++){

            System.out.println("Please enter data for Employee " + (i + 1));

            // FULL NAME
            System.out.print("Full name: ");
            tempS = input.nextLine();
            e.get(i).setFullName(tempS);

            // ID INPUT VALIDATION
            System.out.print("Please enter an ID (8 integers): ");
            tempS = input.nextLine();
            while(!isNumeric(tempS) || tempS.length() != 8){
                System.out.print("Invalid ID. Please enter an ID with 8 integers: ");
                tempS = input.nextLine();
            }
            e.get(i).setID(tempS);  // Accepted if valid

            // HOURLY RATE
            System.out.print("Please enter an hourly rate: ");
            tempS = input.nextLine();
            while(!isNumeric(tempS)){
                System.out.print("Invalid rate. Please make sure it is positive. ");
                tempS = input.nextLine();
            }
            e.get(i).setHourlyPay(Double.parseDouble(tempS));   // Accepted if valid

            // NUMBER OF HOURS
            System.out.print("Please enter the number of hours worked: ");
            tempS = input.nextLine();
            while(!isNumeric(tempS) || Double.parseDouble(tempS) > 40){
                System.out.print("Invalid number. Please make sure it is positive "
                        + "and no more than 40 hours. ");
                tempS = input.nextLine();
            }
            e.get(i).setWorkHours(Double.parseDouble(tempS));   // Accepted if valid
        }
    }

    public static boolean isNumeric(String str)
    {
        // If the string can be converted
        // into integers, the string is fine.
        try{
            Double num = Double.parseDouble(str);
            if (num < 0)
                throw new NumberFormatException();
        }
        // If not, the string contains non-numeric
        // characters. Also checks for negative
        // numbers.
        catch(NumberFormatException ex){
            return false;
        }
        return true;
    }

    public static void write(ArrayList<? extends Person> people, Manager manager, String fileName) {
        // Change the file extension to CSV
        DateFormat df = new SimpleDateFormat("MM/dd/yy HH:mm:ss");

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(fileName, true))) {
            writer.write(df.format(new Date()));  // Writing the timestamp
            writer.newLine();

            if (manager != null) {
                writeManagerDataCSV(writer, manager);
            }

            for (Person person : people) {
                if (person instanceof Employee) {
                    writeEmployeeDataCSV(writer, (Employee) person);
                }
            }

            System.out.println("\nData Saved!\n");
        } catch (IOException ex) {
            System.out.println("Error writing to file '" + fileName + "'");
        }
    }


    private static void writeManagerDataCSV(BufferedWriter writer, Manager manager) throws IOException {
        writer.write("MANAGER,");
        writer.write(manager.getFullName() + "," +
                manager.getID() + "," +
                manager.getHourlyPay() + "," +
                manager.getWorkHours() + "," +
                manager.calc() + "," +
                manager.getOvertimePay() + "," +
                manager.getOvertimeHours() + "," +
                manager.OverTimeCalc() + "," +
                manager.totalCalc());
        writer.newLine();
    }

    private static void writeEmployeeDataCSV(BufferedWriter writer, Employee employee) throws IOException {
        writer.write("EMPLOYEE,");
        writer.write(employee.getFullName() + "," +
                employee.getID() + "," +
                employee.getHourlyPay() + "," +
                employee.getWorkHours() + "," +
                employee.calc());
        writer.newLine();
    }




    public static ArrayList<Person> readDataFromCSV() {
        ArrayList<Person> people = new ArrayList<>();
        String fileName = "output.csv";

        try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] tokens = line.split(",");
                if (tokens.length > 0) {
                    String type = tokens[0].trim();
                    if (type.equals("MANAGER")) {
                        people.add(readManagerDataCSV(tokens));
                    } else if (type.equals("EMPLOYEE")) {
                        people.add(readEmployeeDataCSV(tokens));
                    }
                }
            }
        } catch (IOException ex) {
            System.out.println("Error reading from file '" + fileName + "'");
        }

        return people;
    }

    private static Manager readManagerDataCSV(String[] tokens) {
        Manager manager = new Manager();
        manager.setFullName(tokens[1].trim());
        manager.setID(tokens[2].trim());
        manager.setHourlyPay(Double.parseDouble(tokens[3].trim()));
        manager.setWorkHours(Double.parseDouble(tokens[4].trim()));
        manager.setOvertimePay(Double.parseDouble(tokens[5].trim()));
        manager.setOvertimeHours(Double.parseDouble(tokens[6].trim()));
        return manager;
    }

    private static Employee readEmployeeDataCSV(String[] tokens) {
        Employee employee = new Employee();
        employee.setFullName(tokens[1].trim());
        employee.setID(tokens[2].trim());
        employee.setHourlyPay(Double.parseDouble(tokens[3].trim()));
        employee.setWorkHours(Double.parseDouble(tokens[4].trim()));
        return employee;
    }

}
