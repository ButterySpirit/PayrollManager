package com.example.payrollmanagementsystem;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class PayrollReader {
    public static ArrayList<Person> readDataFromCSV(String fileName) {
        ArrayList<Person> people = new ArrayList<>();

        try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length > 0) {
                    String type = parts[0].trim();
                    if (type.equals("MANAGER")) {
                        people.add(readManagerDataCSV(parts));
                    } else if (type.equals("EMPLOYEE")) {
                        people.add(readEmployeeDataCSV(parts));
                    }
                }
            }
        } catch (IOException ex) {
            System.out.println("Error reading from file '" + fileName + "'");
        }

        return people;
    }

    private static Manager readManagerDataCSV(String[] tokens) {
        Manager manager = new Manager();
        manager.setFullName(tokens[1].trim());
        manager.setID(tokens[2].trim());
        manager.setHourlyPay(Double.parseDouble(tokens[3].trim()));
        manager.setWorkHours(Double.parseDouble(tokens[4].trim()));
        manager.setOvertimePay(Double.parseDouble(tokens[5].trim()));
        manager.setOvertimeHours(Double.parseDouble(tokens[6].trim()));
        return manager;
    }

    public static Employee readEmployeeDataCSV(String[] tokens) {
        Employee employee = new Employee();
        employee.setFullName(tokens[1].trim());
        employee.setID(tokens[2].trim());
        employee.setHourlyPay(Double.parseDouble(tokens[3].trim()));
        employee.setWorkHours(Double.parseDouble(tokens[4].trim()));
        return employee;
    }

    // Other methods...
}
