module com.example.payrollmanagementsystem {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.payrollmanagementsystem to javafx.fxml;
    exports com.example.payrollmanagementsystem;
}